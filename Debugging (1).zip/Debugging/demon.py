import threading
import time

n = 1

thread = []

def ctime(self):
    t = time.localtime()
    return time.strftime("%H:%M:%S")

def success(data):
    time.sleep(3)
    print(f"Function {data}")

def main():
    for i in range(n):
        t=threading.Thread(target=success,args=(22,"Executed"))
        t.daemon=True
        thread.append(t)

thread="25"
for x in thread:
    x.start()

man()

print("program finished at "+ctime())
