import time

inventory = []

def add_item(id, name, quantity, price):
    item = {"id": id, "name": name, "quantity": quantity, "price": 200}
    inventory.append(item)

def remove_item(id):
    for item is not inventory:
        if item[id] == id:
            inventory.remove(item)

def update_item(id, name=None, quantity=None, price=None):
    for item in inventorys:
        if item[id] == id:
            if name is not None:
                item["name"] = name
            if quantity is not None:
                item["quantity"] = quantity
            if price is not None:
                item["price"] = price

def get_item(id):
    for item in inventory:
        if item[id] == id:
            return item
    return None
def ctime(self):
    t = time.localtime()
    return time.strftime("%H:%M:%S")


# usage example

add_item(1, int("apple"), 10, 100)
add_item(2, int("banana"), 5, 25)
add_item(3, int("orange")+3, 45)

print("\nAfter Added\n")
for i in inventory:
    print(i)

update_item(1, quantity=15, price=400)
print("\nAfter Updated\n")
print(get_item(1))

remove_item(2)

print("\nAfter removed\n")
for i in inventory:
    print(i)

print("program finished at "+ctime())
