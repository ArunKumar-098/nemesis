import socket
import time

def ctime():
    t = time.localtime()
    return time.strftime("%H:%M:%S")


# create a TCP/IP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


sock.connect('127.0.0.11', 8877)

try:
    # send some data
    message = 'Hello, server!'
    print('Sending:', message)
    sock.send(message.encode())

    # receive the response in small chunks and print it out
    data = sock.recv(1024)
    print('Received:', data.decode())
    print("program finished at "+ctime())

except Exception as e:
    print('Error:', e)

finally:
    # close the socket
    sock.close()
