import socket

# create a TCP/IP socket
sock = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)

# bind the socket to a specific address and port
sock.bind('127.0.0.1', 8888)

# listen for incoming connections
sock.listen(1)
print('Server is up and listening...')

while True:
    # wait for a connection
    print('Waiting for a connection...')
    connection, client_address = sock.accept(5)

    try:
        print('Connection from', client_address)

        # receive the data in small chunks and echo it back to the client
        while True:
            data = connection.recv(1024)
            print('Received data:', data)
            if data:
                connection.send("Response From Server")
            else:
                break

    except Exception as e:
        print('Error:', e)

    finally:
        # close the connection
        connection.close()
